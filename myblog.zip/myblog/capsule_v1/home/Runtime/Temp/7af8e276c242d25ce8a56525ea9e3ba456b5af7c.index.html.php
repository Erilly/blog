<?php /*%%SmartyHeaderCode:28722548927410c49a7-87174461%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '7af8e276c242d25ce8a56525ea9e3ba456b5af7c' => 
    array (
      0 => 'D:/wamp2/wamp/www/blog/myblog/capsule_v1/home/Tpl\\Index\\index.html',
      1 => 1418173843,
      2 => 'file',
    ),
    'e5619175797836e4263bd5e62930fbe0a53baa0b' => 
    array (
      0 => 'D:/wamp2/wamp/www/blog/myblog/capsule_v1/home/Tpl\\Public\\headbar.html',
      1 => 1418261922,
      2 => 'file',
    ),
    '32ab5f988a6c517b2c8846c3c5729d12892cd1e2' => 
    array (
      0 => 'D:/wamp2/wamp/www/blog/myblog/capsule_v1/home/Tpl\\Public\\footer.html',
      1 => 1418268382,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '28722548927410c49a7-87174461',
  'variables' => 
  array (
    'class' => 0,
    'v' => 0,
    'res' => 0,
    'page' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.6',
  'unifunc' => 'content_548927416b80a',
  'cache_lifetime' => 3600,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_548927416b80a')) {function content_548927416b80a($_smarty_tpl) {?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<title>太空鱼</title>
		<meta name="keywords" content="博客,日记,社交,青春,纪念,文章,太空鱼,太空,鱼,80,90,资料,文章,文档,奋斗"/>
		<meta name="description" content="谁说鱼的记忆只有7秒？“太空鱼”--会保存您的所有记忆！它是一个免费的文章和日记发表平台。在这里，您可以写出您的心声，您的情感和您的文章。快来一起分享您生活的点点滴滴吧！"/>
		<link rel="apple-touch-icon-precomposed" href="__PUBLIC__/images/fish.ico">
		<link rel="shortcut icon" href="__PUBLIC__/images/16.ico" mce_href="__PUBLIC__/images/16.ico" type="image/x-icon">
		<link rel="bookmark" href="__PUBLIC__/images/16.ico" mce_href="__PUBLIC__/images/16.ico" type="image/x-icon">
		<link href="__PUBLIC__/css/page.css" rel="stylesheet" type="text/css" />
		<link href="__PUBLIC__/css/blog-1.css" rel="stylesheet" type="text/css" />
		<script src="__PUBLIC__/js/jquery-1.8.0.min.js" type="text/javascript"></script>
		<script type="text/javascript">
			$(function(){
				//更换验证码
				$(".vimg").click(function(){
					var d = new Date();
					$(this).attr('src', "__APP__/public/verify/"+d.getTime());
				});
			});	
		</script>
	</head>
	<body>
		<!-- 导入头顶条 -->
				<div class="head-top">
			<div class="top-content">
				<a href="__APP__"><div class='logo'></div></a>
				<div class='search'>
					<form action="__APP__/index" method="get">
						<input type="text" name="kwords" value="" class="input-text"/>
						<input type="submit" value="" class="input-sub"/>
					</form>
				</div>
				<ul class="perinfo">
					<li>欢迎,</li>
										<li>[<a class="global_log_btn"><span>登录</span></a>]</li>
					<li><a href="__APP__/public/regist">注册</a></li>
									</ul>
			</div>
		</div>
		<div id="back"></div>
		<div class="index-head">
					<div class="index-title-box">
						<div class="index-user-info">
							<!-- <div class="index-user-say"> -->
								<span class="index-say-content">
									谁说鱼的记忆只有7秒？“太空鱼”--会保存您的所有记忆！它是一个免费的文章和日记发表平台。在这里，您可以写出您的心声，您的情感和您的文章。快来一起分享您生活的点点滴滴吧！
								</span>
							<!-- </div> -->
							<div class="user-line"></div>

						</div>				
					</div>
				</div>

		<div class="index-bg">

			<div class="box">
				<div class="class-list-top">
					<div class="class-list-box">
						<ul>
																					<li>
								<a href="__URL__/index/cid/1.html">
									<div class="class-list-block 
										select-it">
										科技
									</div>
								</a>
							</li>
														<li>
								<a href="__URL__/index/cid/2.html">
									<div class="class-list-block 
										">
										人文
									</div>
								</a>
							</li>
														<li>
								<a href="__URL__/index/cid/3.html">
									<div class="class-list-block 
										">
										财经
									</div>
								</a>
							</li>
														<li>
								<a href="__URL__/index/cid/4.html">
									<div class="class-list-block 
										">
										军事
									</div>
								</a>
							</li>
														<li>
								<a href="__URL__/index/cid/5.html">
									<div class="class-list-block 
										">
										娱乐
									</div>
								</a>
							</li>
														<li>
								<a href="__URL__/index/cid/6.html">
									<div class="class-list-block 
										">
										生活
									</div>
								</a>
							</li>
														<li>
								<a href="__URL__/index/cid/7.html">
									<div class="class-list-block 
										">
										美食
									</div>
								</a>
							</li>
														<li>
								<a href="__URL__/index/cid/8.html">
									<div class="class-list-block 
										">
										时尚
									</div>
								</a>
							</li>
														<li>
								<a href="__URL__/index/cid/9.html">
									<div class="class-list-block 
										">
										旅游
									</div>
								</a>
							</li>
													</ul>
					</div>
				</div>
				<div class="index-main">
										<ul class="index-list-box">
												<li class="index-article-list">
							<a href="__APP__/article/person/uid/5.html">
								<img src="/public/images/1.jpg" alt="" class="index-head-pic">
							</a>
							<div class="index-author">
								<a href="__APP__/article/person/uid/5.html">jack</a>
								<div class="index-article-title">
									<a href="__APP__/article/content/uid/5/aid/1.html" class="article-title-style">不落的太阳</a>
									<div class="index-article-time">
										<span>创建时间：1970-01-01</span>
										<span>访问次数：(336)</span>
									</div>
								</div>
							</div>
							<div class="clearres"></div>
						</li>
												<li class="index-article-list">
							<a href="__APP__/article/person/uid/7.html">
								<img src="/uploads/headpic/7_20141205.jpg" alt="" class="index-head-pic">
							</a>
							<div class="index-author">
								<a href="__APP__/article/person/uid/7.html">Ericyoung</a>
								<div class="index-article-title">
									<a href="__APP__/article/content/uid/7/aid/2.html" class="article-title-style">天蓝蓝</a>
									<div class="index-article-time">
										<span>创建时间：1970-01-01</span>
										<span>访问次数：(223)</span>
									</div>
								</div>
							</div>
							<div class="clearres"></div>
						</li>
												<li class="index-article-list">
							<a href="__APP__/article/person/uid/7.html">
								<img src="/uploads/headpic/7_20141205.jpg" alt="" class="index-head-pic">
							</a>
							<div class="index-author">
								<a href="__APP__/article/person/uid/7.html">Ericyoung</a>
								<div class="index-article-title">
									<a href="__APP__/article/content/uid/7/aid/3.html" class="article-title-style">青草香</a>
									<div class="index-article-time">
										<span>创建时间：1970-01-01</span>
										<span>访问次数：(114)</span>
									</div>
								</div>
							</div>
							<div class="clearres"></div>
						</li>
											</ul>
					<div class="meneame pagebox">  &nbsp;<span class='current'>1</span><a href='/index.php/index/index/p/2.html'>2</a><a href='/index.php/index/index/p/3.html'>3</a> <a href='/index.php/index/index/p/2.html'>下一页</a>  <li class='rows'>第<b>1</b>页/共<b>3</b>页</li></div>
									</div>
				

				<!-- 导入页脚 -->
								<script src="__PUBLIC__/js/per_config.js" type="text/javascript"></script>
				<a href="#back" class="back-top"></a>
				<div class="overburden"></div>
				<div id="error-message"></div>
				<div class="login-window">
					<div class="left-per-title">
						<span class="per-title">登录 太空鱼</span>
						<div class="edit global_close"></div>
					</div>
					<div class="login-box">
						<form id="logform">
							<div class="boxA">
								登录名：
								<input class="fm1" type="text" name="username" placeholder="用户名/Email地址" >
								<a target="_blank" href="__APP__/public/regist">立即注册</a>
							</div>
							<div class="boxA">
								密&nbsp;&nbsp;&nbsp;码：
								<input class="fm1" type="password" name="password">
								<a target="_blank" href="__APP__/public/getpass">找回密码</a>
							</div>
							<div class="boxA">
								验证码：
								<input class="fm2" type="text" name="verify">
								<img src="__APP__/Public/verify/" class="re-vertify-img vimg"/>
							</div>
							<div class="boxB">
								<button name="button" class="button">登 录</button>
							</div>
						</form>
					</div>
				</div>
				<script type="text/javascript">
					/**
					*登陆弹框与关闭,登录,退出
					*/
					$(function(){
						//登陆框显示，关闭
					    $(".global_log_btn").bind("click",function(){
							$(".overburden,.login-window").css({"display":"block"});
						});
						$(".global_close").bind("click",function(){
							$(".overburden,.login-window").css({"display":"none"});
						});
						//登录
						$("#logform").submit(function(){
							var upto="__APP__/Public/checklogin";
							var updata=$(this).serialize();
							doAjax(upto,updata,function(data){
								if(data.status!=1){
									$("#error-message").html(data.info).fadeIn("slow").fadeOut("slow");
								}else{
									$("#error-message").css({"color":"#56007c"}).html(data.info).fadeIn("slow").fadeOut("slow");
									location.reload();
								}
							});
							return false;
						})
						//退出
						$("#logout").bind("click",function(){
							var upto="__APP__/Public/loginout";
							doAjax(upto,'',function(data){
								if(data.status==1){
									location.reload();
								}
							});
						});
					})
				</script>
				<div class="foot">
					<ul class="foot-content">
						<li>Copyright  ©2014 <span>&nbsp;太空鱼 &nbsp;</span> 联系方式 QQ:1617507676</li>		
					</ul>
					<div class="bottom-height"></div>
				</div>
			</div>
		</div>
	</body>
</html><?php }} ?>