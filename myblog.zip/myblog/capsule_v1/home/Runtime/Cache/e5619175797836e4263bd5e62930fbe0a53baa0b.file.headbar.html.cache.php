<?php /* Smarty version Smarty-3.1.6, created on 2014-12-11 13:10:25
         compiled from "D:/wamp2/wamp/www/blog/myblog/capsule_v1/home/Tpl\Public\headbar.html" */ ?>
<?php /*%%SmartyHeaderCode:12675548927414939a6-87853950%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'e5619175797836e4263bd5e62930fbe0a53baa0b' => 
    array (
      0 => 'D:/wamp2/wamp/www/blog/myblog/capsule_v1/home/Tpl\\Public\\headbar.html',
      1 => 1418261922,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '12675548927414939a6-87853950',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.6',
  'unifunc' => 'content_5489274154a6a',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5489274154a6a')) {function content_5489274154a6a($_smarty_tpl) {?>		<div class="head-top">
			<div class="top-content">
				<a href="__APP__"><div class='logo'></div></a>
				<div class='search'>
					<form action="__APP__/index" method="get">
						<input type="text" name="kwords" value="<?php echo $_REQUEST['kwords'];?>
" class="input-text"/>
						<input type="submit" value="" class="input-sub"/>
					</form>
				</div>
				<ul class="perinfo">
					<li>欢迎,</li>
					<?php if (!$_SESSION['uid']){?>
					<li>[<a class="global_log_btn"><span>登录</span></a>]</li>
					<li><a href="__APP__/public/regist">注册</a></li>
					<?php }else{ ?>
					<li>[<a href="__APP__/article/person/uid/<?php echo $_SESSION['uid'];?>
.html"><span><?php echo $_SESSION['name'];?>
</span></a>]
						<ul>
							<li><a href="__APP__/article/reset/uid/<?php echo $_SESSION['uid'];?>
.html" >修改密码</a></li>
							<li><a href="javascript:;" id="logout">退出</a></li>
						</ul>
					</li>
					<!-- <li><a href="#">消息</a>
						<ul>
							<li><a href="__APP__/article/comment">查看评论</a></li>
							<li><a href="__APP__/article/message/uid/<?php echo $_SESSION['uid'];?>
">查看留言</a></li>
						</ul>
					</li> -->
					<?php }?>
				</ul>
			</div>
		</div><?php }} ?>