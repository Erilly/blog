<?php /* Smarty version Smarty-3.1.6, created on 2014-12-11 13:00:48
         compiled from "D:/wamp2/wamp/www/blog/myblog/capsule_v1/home/Tpl\Article\content.html" */ ?>
<?php /*%%SmartyHeaderCode:1708654892500048ab1-94903499%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '2141f588ac1db015f1984bd7c4d8601ecd300e0e' => 
    array (
      0 => 'D:/wamp2/wamp/www/blog/myblog/capsule_v1/home/Tpl\\Article\\content.html',
      1 => 1418267803,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1708654892500048ab1-94903499',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'userinfo' => 0,
    'article' => 0,
    'commentCount' => 0,
    'comment' => 0,
    'v' => 0,
    'loadStatus' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.6',
  'unifunc' => 'content_54892500360dc',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_54892500360dc')) {function content_54892500360dc($_smarty_tpl) {?><?php if (!is_callable('smarty_modifier_date_format')) include 'D:\\wamp2\\wamp\\www\\blog\\myblog\\ThinkPHP\\Extend\\Vendor\\Smarty\\plugins\\modifier.date_format.php';
?><?php echo $_smarty_tpl->getSubTemplate ("Public/header.html", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>

		<div class="right">
			<div class="left-per-title">
				<span class="per-title"><a href="__URL__/articlelist/uid/<?php echo $_smarty_tpl->tpl_vars['userinfo']->value['id'];?>
/cid/<?php echo $_smarty_tpl->tpl_vars['article']->value['cid'];?>
.html"><?php echo getClassName($_smarty_tpl->tpl_vars['article']->value['cid']);?>
</a> > <?php echo $_smarty_tpl->tpl_vars['article']->value['title'];?>
</span>
			</div>
			<div class="right-content-box">
				<div class="right-content">
					<div class="right-title-box">
						<h2 class="right-title"><?php echo $_smarty_tpl->tpl_vars['article']->value['title'];?>
</h2>
						<span><?php echo smarty_modifier_date_format($_smarty_tpl->tpl_vars['article']->value['ctime'],'%Y-%m-%d');?>
</span>
						<div class="clearres"></div>
					</div>
					<div class="right-article">
						<?php echo $_smarty_tpl->tpl_vars['article']->value['content'];?>

						<div class="bottom-height"></div>
					</div>

					<div class="right-article-bar">
						<span class="article-discuss-left">评论(<?php echo $_smarty_tpl->tpl_vars['commentCount']->value;?>
)</span>
						<span class="article-discuss-right"><a href="#here">[发评论]</a></span>
					</div>
					<div class="discuss-content">
						<ul id="commentBox">
							<?php  $_smarty_tpl->tpl_vars["v"] = new Smarty_Variable; $_smarty_tpl->tpl_vars["v"]->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['comment']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars["v"]->key => $_smarty_tpl->tpl_vars["v"]->value){
$_smarty_tpl->tpl_vars["v"]->_loop = true;
?>
							<li>
								<div class="comment-pic">
									<a href="__URL__/person/uid/<?php echo $_smarty_tpl->tpl_vars['v']->value['euid'];?>
.html">
										<img src="<?php echo getheadpic($_smarty_tpl->tpl_vars['v']->value['euid']);?>
" width="50" height="50" class="comment-imag"/>
									</a>
									<a href="__URL__/person/uid/<?php echo $_smarty_tpl->tpl_vars['v']->value['euid'];?>
.html" class="comment-uname"><?php echo getName($_smarty_tpl->tpl_vars['v']->value['euid']);?>
</a>
								</div>
								<div class="comment-content"><?php echo $_smarty_tpl->tpl_vars['v']->value['comment'];?>
</div>
								<div class="clearres"></div>
								<div class="discuss-ctime">
									<span><?php echo smarty_modifier_date_format($_smarty_tpl->tpl_vars['v']->value['ctime'],'%Y-%m-%d %H:%M');?>
</span>
								</div>
							</li>
							<?php } ?>

						</ul>
					</div>
					<div style="text-align:center;color:#774ea7">
						<?php if ($_smarty_tpl->tpl_vars['loadStatus']->value==1){?>
						<span id="load-more" style="cursor:pointer;">加载更多</span>
						<?php }?>
					</div>
					<div class="right-article-bar">
						<span class="article-discuss-left" id="here">发表评论</span>	
					</div>
					<script type="text/javascript">
						$(function(){
							//提交评论
							$("#commentform").submit(function(){
								var upto="__APP__/ajax/doComment";
								var updata=$(this).serialize();
								doAjax(upto,updata,function(msg){
									if(msg.status!=1){
										$("#error-message").html(msg.info).fadeIn("fast").delay("800").fadeOut("slow");
									}else{
										$("#commentBox").prepend(msg.data);
										$("#error-message").css({"color":"#56007c"}).html(msg.info).fadeIn("fast").delay("800").fadeOut("slow");
										//更换验证码
										var d = new Date();
										$(".vimg").attr('src', "__APP__/public/verify/"+d.getTime());
										//清空编辑器内容
										clrearIt();
										$("#reg-verify").val(" ");
										
									}
								});
								return false;
							});

							//加载评论
							var p=0;
							$("#load-more").bind('click',function(){
								var upto="__APP__/ajax/loadMore";
								var updata={"aid":<?php echo $_smarty_tpl->tpl_vars['article']->value['id'];?>
,"p":p};
								doAjax(upto,updata,function(msg){
									if(msg.info==1){
										$("#commentBox").append(msg.data);
										p+=3;
									}
									if(msg.status==0){
										$("#load-more").hide();
									}
								})
							});
						})
							
					</script>
					<div class="right-discuss-box">
						<form id="commentform">
							<ul>
								<?php if ($_SESSION['uid']){?>
								<input type="hidden" name="aid" value="<?php echo $_smarty_tpl->tpl_vars['article']->value['id'];?>
" />
								<li>
									<script src="__PUBLIC__/ueditor1_4_3/ueditor.parse.js"></script>
									 <!-- 配置文件 -->
								    <script type="text/javascript" src="__PUBLIC__/ueditor1_4_3/ueditor.config.js"></script>
								    <!-- 编辑器源码文件 -->
								    <script type="text/javascript" src="__PUBLIC__/ueditor1_4_3/ueditor.all.min.js"></script>
									<!-- 加载编辑器的容器 -->
							        <script id="container" name="content" type="text/plain" style="height:300px;"></script>
							        <!-- 实例化编辑器 -->
							        <script type="text/javascript">
								        var ue = UE.getEditor('container',{ 
								        	autoHeightEnabled: false,
								        	autoFloatEnabled: false,
								        	initialFrameHeight :200,
								        	maximumWords:300,
								        	toolbars: [[
												        'undo', //撤销
												        'redo', //重做
												        'emotion', //表情
												     	'forecolor', //字体颜色
												        'cleardoc', //清空文档
												        'spechars', //特殊字符
												        'help', //帮助
													    ]]
								        });
										function clrearIt(){
											ue.execCommand('cleardoc');
										}
								    </script>
							    </li>
							    <li class="verfy-posit">
									<label class="setinfo-tag"><i></i>验&nbsp;&nbsp;证&nbsp;&nbsp;码：</label>
									<div class="re-input re-verify">
										<input type="text" name="verify" class="re-input-bor re-verify-input" id="reg-verify"/>
										<img src="__APP__/Public/verify/" class="re-vertify-img vimg"/>
									</div>
									<span id="reg-verifyTip"></span>
								</li>
							    <li>
									<div class="discuss-sub"><button class="button">评 论</button></div>
								</li>
								<?php }else{ ?>
								<li style="text-align:center;color:#56007c"  class="global_log_btn">评论，请先登录!</li>
								<?php }?>
							</ul>
						</form>
					</div>
				</div>
				<div class="bottom-height"></div>
			</div>
		</div>
	</div>

<?php echo $_smarty_tpl->getSubTemplate ("Public/footer.html", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>
<?php }} ?>