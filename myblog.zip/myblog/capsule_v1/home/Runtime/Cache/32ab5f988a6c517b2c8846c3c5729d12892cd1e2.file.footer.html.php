<?php /* Smarty version Smarty-3.1.6, created on 2014-12-11 13:00:21
         compiled from "D:/wamp2/wamp/www/blog/myblog/capsule_v1/home/Tpl\Public\footer.html" */ ?>
<?php /*%%SmartyHeaderCode:25977548924e5cd81d6-09318952%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '32ab5f988a6c517b2c8846c3c5729d12892cd1e2' => 
    array (
      0 => 'D:/wamp2/wamp/www/blog/myblog/capsule_v1/home/Tpl\\Public\\footer.html',
      1 => 1418268382,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '25977548924e5cd81d6-09318952',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.6',
  'unifunc' => 'content_548924e5dcbdd',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_548924e5dcbdd')) {function content_548924e5dcbdd($_smarty_tpl) {?>				<script src="__PUBLIC__/js/per_config.js" type="text/javascript"></script>
				<a href="#back" class="back-top"></a>
				<div class="overburden"></div>
				<div id="error-message"></div>
				<div class="login-window">
					<div class="left-per-title">
						<span class="per-title">登录 太空鱼</span>
						<div class="edit global_close"></div>
					</div>
					<div class="login-box">
						<form id="logform">
							<div class="boxA">
								登录名：
								<input class="fm1" type="text" name="username" placeholder="用户名/Email地址" >
								<a target="_blank" href="__APP__/public/regist">立即注册</a>
							</div>
							<div class="boxA">
								密&nbsp;&nbsp;&nbsp;码：
								<input class="fm1" type="password" name="password">
								<a target="_blank" href="__APP__/public/getpass">找回密码</a>
							</div>
							<div class="boxA">
								验证码：
								<input class="fm2" type="text" name="verify">
								<img src="__APP__/Public/verify/" class="re-vertify-img vimg"/>
							</div>
							<div class="boxB">
								<button name="button" class="button">登 录</button>
							</div>
						</form>
					</div>
				</div>
				<script type="text/javascript">
					/**
					*登陆弹框与关闭,登录,退出
					*/
					$(function(){
						//登陆框显示，关闭
					    $(".global_log_btn").bind("click",function(){
							$(".overburden,.login-window").css({"display":"block"});
						});
						$(".global_close").bind("click",function(){
							$(".overburden,.login-window").css({"display":"none"});
						});
						//登录
						$("#logform").submit(function(){
							var upto="__APP__/Public/checklogin";
							var updata=$(this).serialize();
							doAjax(upto,updata,function(data){
								if(data.status!=1){
									$("#error-message").html(data.info).fadeIn("slow").fadeOut("slow");
								}else{
									$("#error-message").css({"color":"#56007c"}).html(data.info).fadeIn("slow").fadeOut("slow");
									location.reload();
								}
							});
							return false;
						})
						//退出
						$("#logout").bind("click",function(){
							var upto="__APP__/Public/loginout";
							doAjax(upto,'',function(data){
								if(data.status==1){
									location.reload();
								}
							});
						});
					})
				</script>
				<div class="foot">
					<ul class="foot-content">
						<li>Copyright  ©2014 <span>&nbsp;太空鱼 &nbsp;</span> 联系方式 QQ:1617507676</li>		
					</ul>
					<div class="bottom-height"></div>
				</div>
			</div>
		</div>
	</body>
</html><?php }} ?>