<?php
/**
*自定义公共函数库
*/
require_cache('./common.inc.php'); //导入公共自定义函数库
