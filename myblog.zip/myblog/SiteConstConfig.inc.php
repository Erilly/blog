<?php 
/**
 * 站点常量的定义集合
 */
define('SITE_SESSION_DOMAIN', '');
define('SITE_COOKIE_DOMAIN', '');

#定义网站域名
define('SITE_DOMAIN', 'http://www.myblog.com');
define('SITE_PATH', 'D:/wamp2/wamp/www/blog/myblog/capsule_v1/');
define('SITE_URL','');

#邮件发送配置
define('MAIL_SMTP',     'smtp.yeah.net');
define('MAIL_PORT',     '25');
define('MAIL_USERNAME', 'spacefish@yeah.net');
define('MAIL_PASSWORD', 'xytsyj621');

#SEO相关配置
define('SITE_NAME', '太空鱼');
define('SITE_TITLE', '太空鱼');
define('SITE_KEYWORD',   '博客,日记,社交,青春,纪念,文章,太空鱼,太空,鱼,80,90,资料,文章,文档,奋斗');
define('SITE_DESCRIPTION', '谁说鱼的记忆只有7秒？“太空鱼”--会保存您的所有记忆！它是一个免费的文章和日记发表平台。在这里，您可以写出您的心声，您的情感和您的文章。快来一起分享您生活的点点滴滴吧！');

